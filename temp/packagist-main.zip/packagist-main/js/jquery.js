import jQuery from 'jquery';
window.jQuery = window.$ = jQuery;
